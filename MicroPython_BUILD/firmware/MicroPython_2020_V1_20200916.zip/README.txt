BaseOn:
https://github.com/loboris/MicroPython_ESP32_psRAM_LoBo

Tools link:
https://www.espressif.com/sites/default/files/tools/flash_download_tool_v3.8.5.zip

API ref:
https://github.com/loboris/MicroPython_ESP32_psRAM_LoBo/wiki

Source & examples:
https://github.com/lewisxhe/MicroPython-for-TTGO-T-Watch